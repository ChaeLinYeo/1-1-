def anagram():
   s= input()
   s=eval(s)
   s_1 = s[0:]
   for i in range(len(s)):
      s_1[i]= list(str(s_1[i]))
      s_1[i].sort()

   str_s=s_1[0:]
   for i in range(len(s)):
      str_s[i]= str(s_1[i][0]+s_1[i][1]+s_1[i][2]+s_1[i][3]) + "."+ str(i)
   str_s.sort()

   result_before=''
   for i in range(len(s)-1):
      if str_s[i][:4]==str_s[i+1][:4]:
         a= int(str_s[i][5:])
         result_before += str(s[a]) + str(" ")
         if str_s[i+1][:4] != str_s[i+2][:4]:
            a= int(str_s[i+1][5:])
            result_before += str(s[a]) + str("\n")

   return result_before