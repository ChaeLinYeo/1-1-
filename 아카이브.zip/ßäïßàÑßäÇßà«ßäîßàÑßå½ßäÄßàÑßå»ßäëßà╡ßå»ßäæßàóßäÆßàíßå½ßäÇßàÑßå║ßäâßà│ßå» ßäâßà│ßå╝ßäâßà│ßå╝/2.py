def anagram():
	s=eval(input())
	ss=s[:]
	ss1=ss[0:]
	i=0
	result=""
	while 0<=i<=len(ss)-1:
		ss[i]=list(ss[i])
		i+=1

	for i in range(len(ss)):
		ss[i].sort()
		ss[i]=list(str(ss[i]))

	for i in range(len(ss)):
		ss[i].append(i)
	
	for i in range(len(ss)-1):
		if ss1[i][:4] == ss1[i+1][:4]:
			x=int(ss1[i+1])
			result += 
	print(result)
anagram()

#['0952', '5239', '1270', '8581', '7458', '3414', '7906', '2356', '4360', '3491', '6232', '5927', '2735', '2509', '5849', '8457', '9340', '1858', '8602', '5784']