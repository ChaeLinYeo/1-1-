class Reader:
    """defines class for Input View"""
    @staticmethod
    def register():
        """gets player's name and returns it (string)"""
        return input("Enter your name : ") 

    @staticmethod
    def ox(message):
        """returns True if player inputs 'o' or 'O', 
                   False if player inputs 'x' or 'X'"""
        response = input(message).lower()
        while not (response == 'o' or response == 'x'):
            response = input(message).lower()
        return response == 'o'