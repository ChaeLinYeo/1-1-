
def __init__(self, suit, rank, face_up=True):
	if suit in Card.__suits and rank in Card.__ranks:
		self.__suit = suit
		self.__rank = rank
		self.__face_up = face_up 
	else:
		print("Error: Not a valid card")
	self.__value = Card.__ranks.index(self.__rank) + 1
	if self.__value > 10:
		self.__value = 10

def __init__(self):
	self.__deck = Card.fresh_deck()
	print("<< A brand-new deck of card! >>")

def next(self, open=True):
	if self.__deck == []:
		self.__deck = Card.fresh_deck()
		print("<< A brand-new deck of card! >>")
	card = self.__deck.pop()
	if open :
		card.flip()
	return card

def __init__(self, name="Dealer"):
	self.__name = name 
	self.__hand = []

@property
def name(self):
	return self.__name
@property
def total(self):
	point = 0
	number_of_ace = 0
	for card in self.__hand:
		if card.rank == 'A':
			point += 11
			number_of_ace += 1
		else:
			point += card.value
	while point > 21 and number_of_ace > 0:
		point -= 10
		number_of_ace -= 1
	return point

def get(self, card):
	self.__hand.append(card)

def clear(self):
	self.__hand = []

def open(self):
	for card in self.__hand:
		if not card.face_up:
			card.flip()

class PlayerHand(Hand):
	def __init__(self, name):
		super(),__init__(name)
		self.__chips = 0

	def earn_chips(self, n):
		self.__chips += n
		print("Your have", self.__chips, "chips.")

	def lose_chips(self, n):
		self.__chips -= n
		print("Your have", self.__chips, "chips.")

class Reader:
	@staticmethod
	def register():
		return input("Enter your name: ")

	@staticmethod
	def ox(message):
		response = input(message).lower()
		while not (response == 'o' or response == 'x'):
			response = input(message).lower()
		return response == 'o'

def __init__(self, name):
	self.__player = PlayerHand(name)
	self.__dealer = Hand()
	slef.__dealer = Deck()


def play(self):
	print("== new game ==")
	player = self.__player
	dealer = self.__dealer
	deck = self.__deck
	player.get(deck.next())
	dealer.get(deck.next())
	player.get(deck.next())
	dealer.get(deck.next(open=False))
	print("Dealer :", dealer)
	print(player.name, ":", player)
	if player.total == 21:
		print("Blackjack!", player.name, "wins.")
		player.earn_chips(2)
	else:
		while player.total < 21 and Reader.ox(player.name + ": Hit?(o/x) "):
			player.get(deck.next())
			print(player.name, ":", player)
		if player.total > 21:
			print(player.name, "busts!")
			player.lose_chips(1)
		else:
			while dealer.total <= 16:
				dealer.get(deck.next())
			if dealer.total > 21:
				print("Dealer busts!")
				player.earn_chips(1)
			elif dealer.total == player.total:
				print("We draw.")
			elif dealer.total > player.total:
				print(player.name, "loses.")
				player.lose_chips(1)
			else:
				print(player.name, "wins.")
				player.earn_chips(1)
			dealer.open()
			print("Dealer :", dealer)
	player.clear()
	dealer.clear()


def main():
	print("Welcome to SMaSH Casino!")
	name = Reader.register()
	game = BlackjackController(name)
	while True:
		game.play()
		if not Reader.ox("Play more, " + name + "? (o/x"):
			break
		print("Bye," + name + "!")