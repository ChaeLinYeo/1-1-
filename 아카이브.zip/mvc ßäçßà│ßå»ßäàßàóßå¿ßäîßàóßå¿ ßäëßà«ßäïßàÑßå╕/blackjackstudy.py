import random
class Card:
	__suits = ["Diamond", "Heart", "Spade", "Clover"]
	__rank = ["A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q,", "K"]

def __init__(self, suit, rank, face_up=False): 
	if suit in Card.__suits and rank in Card.__ranks: 
		self.__suit = suit 
		self.__rank = rank 
		self.__face_up = face_up 
	else: 
		print("Error: Not a valid card")      

	self.__value = Card.__ranks.index(self.__rank) + 1      
	if self.__value > 10: 
		self.__value = 10

	@property
	def suit(self):
		return self.__suit

	@property
	def rank(self):
		return self.__rank

	@property
	def face_up(self):
		return self.__face_up
	def __str__(self):
		if self.__face_up:
			return self.__suit + ":" + self.__rank
		else:
			return "(XXXX)"
	def flip(self):
		self.__face_up = not self.__face_up


	@staticmethod
	def fresh_deck():
		deck = []
		for s in Card.__suits:
			for r in Card.__rank:
				deck.append(Card(s,r))
		random.shuffle(deck)
		return deck

class Deck:
	def __init__(self): 
		self.__deck = Card.fresh_deck() 
		print("<< A brand-new deck of card! >>")

	def next(open=True):
		if self.__deck == []:
			self.__deck = Card.fresh_deck() 
			print("<< A brand-new deck of card! >>")
		card = self.__deck.pop()
		if open : 
			card.flip() 
		return card
