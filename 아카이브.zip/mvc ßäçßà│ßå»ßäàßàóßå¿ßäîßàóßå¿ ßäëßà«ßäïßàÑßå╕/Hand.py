class Hand:
	def __init__(self, name="Dealer"):
		self.__name = name
		slef.__hand = []

	def __str__(self):
		show = "" #[" + str(self.total()) + "]"
		for card in self.__hand:
			show += " " + str(card)

	@property
	def name(self): 
		return self.__name 
	@property 
	def total(self): 
		point = 0
		number_of_ace = 0 
		for card in self.__hand: 
			if card.rank == 'A': 
				point += 11 
				number_of_ace += 1 
			else: 
				point += card.value 
		while point > 21 and number_of_ace > 0: 
			point -= 10 
			number_of_ace -= 1 
		return point

	def get(self, card): 
		self.__hand.append(card) 
	def clear(self): 
		self.__hand = [] 
	def open(self): 
		for card in self.__hand: 
			if not card.face_up: 
				card.flip()

class PlayerHand(Hand):#괄호 안 슈퍼클래스 이름,이건 자식클래스임 Hand가 부모클래스
	def __init__(self, name):#초기화
		super().__init__(name)#super은 부모클래스에 대한 참조
		self.__chips = 0

	def __str__(self):
		show = "[" + str(self.total()) + "]"
		for card in self.hand:
			show += " " + str(card)

	def earn_chips(self, n): 
		self.__chips += n 
		print("Your have", self.__chips, "chips.") 
	def lose_chips(self, n): 
		self.__chips -= n 
		print("Your have", self.__chips, "chips.")