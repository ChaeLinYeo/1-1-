from card import *
from hand import *
from reader import *
class BJController:
	def __init__(self, name): 
		self.__player = PlayerHand(name) 
		self.__dealer = Hand() 
		self.__dealer = Deck()

	def play(self): 
		print("== new game ==") 
		player = self.__player 
		dealer = self.__dealer 
		deck = self.__deck 
		player.get(deck.next()) #덱에서 카드 한장씩 가져오기.
		dealer.get(deck.next()) 
		player.get(deck.next()) 
		dealer.get(deck.next(open=False)) #딜러는 카드가 안보이게 숨겨야함
		print("Dealer :", dealer) 
		print(player.name, ":", player) 
		if player.total == 21: 
			print("Blackjack!", player.name, "wins.") 
			player.earn_chips(2) 
		else: 
			while player.total < 21 and Reader.ox(player.name + ": Hit?(o/x) "): #리더는 뷰, 오엑스는 질문하는함
				player.get(deck.next()) 
				print(player.name, ":", player) 
			if player.total > 21: 
				print(player.name, "busts!") 
				player.lose_chips(1) 
			else: 
				while dealer.total <= 16: 
					dealer.get(deck.next()) 
				if dealer.total > 21: 
					print("Dealer busts!") 
					player.earn_chips(1) 
				elif dealer.total == player.total: 
					print("We draw.") 
				elif dealer.total > player.total: 
					print(player.name, "loses.") 
					player.lose_chips(1) 
				else: 
					print(player.name, "wins.") 
					player.earn_chips(1) 
			dealer.open() 
			print("Dealer :", dealer) 
		player.clear() 
		dealer.clear() #한판끝나고 카드 초기화

def main():
	print("Welcome to SMaSH Casino!") 
	name = Reader.register() 
	game = BJController(name) 
	while True: 
		game.play() 
		if not Reader.ox("Play more, " + name + "? (o/x) "): 
			break
	print("Bye, " + name + "!")


main()

