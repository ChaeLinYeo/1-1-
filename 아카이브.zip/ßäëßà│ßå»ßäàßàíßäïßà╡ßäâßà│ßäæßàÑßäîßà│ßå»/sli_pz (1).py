

def create_init_board():

	return[[0,15,14,13],[12,11,10,9],[8,7,6,5],[4,3,2,1]]
def set_goal_board():
	return [[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,0]]

def print_board(board):
	for row in board:
		for num in row:
			if num == 0:
				print("  ",end=' ')
			elif 10 <= num <= 15:
				print(num,end=" ")
			else:
				print(str(num).rjust(2),end=' ')
		print()

def get_number():
	num = input("Type the number you want to move (Type 0 to quit): ")
	while not(num.isdigit() and 0<=int(num)<=15):
		num = input("Type the number you want to move (Type 0 to quit): ")
	return int(num)


def find_position(num,board):
	for i in range(4):
		for j in range(4):
			if num == board[i][j]:
				return (i,j)

def move(pos,empty,board):
	(x,y) = pos
	if empty == (x-1,y) or empty == (x+1,y) or empty==(x,y-1) or empty == (x,y+1):
		board[empty[0]][empty[1]] = board[x][y]
		board[x][y] = 0
		return (pos,board)
	else:
		print('Can\'t move! Try again.')
		return (empty,board)







def sliding_puzzle():
	board = create_init_board()
	goal = set_goal_board()
	empty = (0,0)
	while True:
		print_board(board) #중첩 리스츠트로 표현된 퍼즐 보드를 인수로 받아 실행창에 보드를 프린트
		if board == goal:
			print("Congrtulations!")
			break
		num = get_number() # 실행창에서 메세지를 보여주며 사용자에게서 0부터 15사이의 입력을 받아서 정수로 바꿔내주는 함수 
		if num == 0:
			break
		pos = find_position(num,board) # num과 board를 인수로 받아 num의 위치좌표를 가르쳐줌
		(empty,board) = move(pos,empty,board) #이동할 번호의 위치좌표 pos 와 빈칸의 좌표 empty,board를 인수로 받아 pos가 empty의 이웃에 있는질 확인, 바뀐 empty,board 넣어줌 
	print("Please come again.")





sliding_puzzle()