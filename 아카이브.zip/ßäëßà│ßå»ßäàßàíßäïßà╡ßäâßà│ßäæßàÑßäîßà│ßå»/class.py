class Card:
	__suits = ("Diamond", "Heart", "Spade", "Clover")
	__ranks = ("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")

	@staticmethod
	def fresh_deck():
		cards=[]
		for s in Card.__suits:
			for r in Card.__ranks:
				cards.append(Card(s,r,False))
		random.shuffle(cards)
		return cards


	def __init__(self, suit, rank, face_up):          
		self.__suit = s
		self.__rank = r
		self.__face_up = fup

	@property
	def suit(self):
		return self.__suit

	@property
	def suit(self):
		return self.__rank

	@property
	def suit(self):
		return self.__face_up

	def suit(self):
		return self.__suit

	def __str__(self):
		if self.__faceup:
			return self.__suit + ":" + self.__rank
		else:
			return "(hidden)"

	def flip(self):
		selfr.__faceup = not self.__faceup