import random
class Reader:
	@staticmethod
	def get_number(size):
		num = input("Type the number you want to move (Type 0 to quit): ")
		while not (num.isdigit() and 0 <= int(num) <= size * size - 1):
			num = input("Type the number you want to move (Type 0 to quit): ")
		return int(num)


######


class SlidingBoard:
	@staticmethod
	def create_init_board(size):
		s=[]
		ss=[]
		num=0
		snum=0
		while 0<=num<=(size**2)-1:
			s.append(num)
			num+=1
		random.shuffle(s)
		for i in range(size):
			ss.append([])
			for k in range(size):
				ss[i].append(s[snum])
				snum+=1
		return ss

	@staticmethod
	def set_goal_board(size):
		s=[]
		num=1
		ss=[]
		snum=0
		while 1<=num<=(size**2):
			if num==size**2:
				s.append(0)
			else:
				s.append(num)
			num+=1
		for i in range(size):
			ss.append([])
			for k in range(size):
				ss[i].append(s[snum])
				snum+=1
		return ss

	@staticmethod
	def create_board(numbers):
		print("S |  0  1  2  3")
		print("- + -----------")
		i = 0
		for row in board:
			print(i,"|",end=' ')
			for item in row:
				if item == 0:
					print("  ", end=" ")
				elif 10 <= item <= 15:
					print(item,end=" ")
				else:
					print(str(item).rjust(2),end=" ")
			print()
			i += 1


	def __init__(self, size):
		self.__board = SlidingBoard.create_init_board(size)
		self.__empty = self.find_position(0)


	@property
	def board(self):
		return self.__board

	def find_position(self,num):
		for i in range(int(size)):
			for j in range(int(size)):
				if num == self.__board[i][j]:
					return (i,j)

	def move(pos,empty,board):
		(x,y) = pos
		if empty == (x-1,y) or empty == (x+1,y) or empty==(x,y-1) or empty == (x,y+1):
			board[empty[0]][empty[1]] = board[x][y]
			board[x][y] = 0
			empty = (x,y)
			#return (pos,board)
		else:
			print('Can\'t move! Try again.')
			#return (empty,board)

	def print_board(self, size):
		for row in self.__board:
			for num in row:
				if num == 0:
					print("  ",end=' ')
				else:
					print(str(num).rjust(2),end=' ')
			print()



######



class SlidingPuzzleController:
	def __init__(self, size):
		self.__slider = SlidingBoard(size)
		self.__goal = SlidingBoard.set_goal_board(size)
		self.__size = size


	def play(self):#slidingpuzzle
		while True:
			self.__slider.print_board(self.__size)
			if self.__slider.board == self.__goal:
				print("Congrtulations!")
				break
			num = Reader.get_number(self.__size) # 실행창에서 메세지를 보여주며 사용자에게서 0부터 15사이의 입력을 받아서 정수로 바꿔내주는 함수 
			if num == 0:
				break
			pos = SlidingBoard.find_position(num, self.__slider.board) # num과 board를 인수로 받아 num의 위치좌표를 가르쳐줌
			(empty,board) = SlidingBoard.move(pos,empty,board) #이동할 번호의 위치좌표 pos 와 빈칸의 좌표 empty,board를 인수로 받아 pos가 empty의 이웃에 있는질 확인, 바뀐 empty,board 넣어줌 
		print("Please come again.")



######



def main():
	import sys
	size = sys.argv[1]
	if size.isdigit() and int(size) > 1:
		SlidingPuzzleController(int(size)).play()
	else:
		print("Not a proper system argument.")



if __name__ == "__main__":
	import sys
	size = sys.argv[1]
	if size.isdigit() and int(size) >1:
		SlidingPuzzleController(int(size)).play()
	else:
		print("Not a proper system argument. ")

