import random
class Reader:
	@staticmethod
	def get_number(size):
		num = input("Type the number you want to move (Type 0 to quit): ")
		while not (num.isdigit() and 0 <= int(num) <= size * size - 1):
			num = input("Type the number you want to move (Type 0 to quit): ")
		return int(num)




class SlidingBoard:
	@staticmethod
	def create_board(numbers):
		print("S |  0  1  2  3")
		print("- + -----------")
		i = 0
		for row in board:
			print(i,"|",end=' ')
			for item in row:
				if item == 0:
					print("  ", end=" ")
				elif 10 <= item <= 15:
					print(item,end=" ")
				else:
					print(str(item).rjust(2),end=" ")
			print()
			i += 1

	def create_init_board(size):
		numbers = [n for n in range(16)]
		random.shuffle(numbers)
		board, empty = [], None
		for r in range(4):
			k = r * 4
			row = numbers[k:k+4]
			if 0 in row:
				c = row.index(0)
				empty = (r,c)
			board.append(numbers[k:k+4])
		return (board, empty)


	def __init__(self, size):
		self.__board = SlidingBoard.create_init_board()
		self.__empty = find_position(0,board)

	@property
	def board(self):
		return self.__board


	def find_position(self, num):
		for i in range(len(self.__board)):
			for j in range(len(self.__board)):
				if num == self.__board[i][j]:
					return (i, j)

	def move(pos,empty,self):
		(x,y) = pos
		if self.__empty == (x-1,y) or self.__empty == (x+1,y) or \
			slef.__empty == (x,y-1) or self.__empty == (x,y+1):
			self.__board[self.__empty[0]][self.__empty[1]] = self.__board[x][y]
			self.__board[x][y] = 0
			return (pos,self.__board)
		else:
			print("Can't move! Try again.")
			return (self.__empty,self.__board)




class SlidingPuzzleController:
	def play(self):
		self.__slider = SlidingBoard(size)
		self.__goal = SlidingBoard.set_goal_board(size)
		self.__size = Reader.get_number(size)



def main():
	import sys
	size = sys.argv[1]
	if size.isdigit() and int(size) > 1:
		SlidingPuzzleController(int(size)).play()
	else:
		print("Not a proper system argument.")
